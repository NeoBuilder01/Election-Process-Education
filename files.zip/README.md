# 🗳️ Election Process Assistant

An interactive, easy-to-follow web app that helps users understand the election process — including timelines, key stages, voter roles, and how results are certified.

![HTML](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)
![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)

---

## 📖 About

The **Election Process Assistant** is a single-page, no-dependency web application that makes civic education accessible and engaging. It walks users through the full election lifecycle — from candidate registration to result certification — with interactive timelines, explainer cards, a roles guide, a quiz, and a glossary.

Built as a pure HTML/CSS/JS file — no build tools, no frameworks, no server needed.

---

## ✨ Features

- **📅 Interactive Timeline** — Step-by-step visual walkthrough of the full election process with expandable detail panels
- **💡 Key Concepts Explorer** — Tap-to-explore cards covering voter registration, electoral systems, gerrymandering, campaign finance, and more
- **👥 Who Does What** — Roles and responsibilities of every participant: voters, candidates, election commissions, media, observers, and the judiciary
- **🧠 Knowledge Quiz** — 6-question quiz with instant feedback and explanations
- **📖 Glossary** — 20+ searchable election terms explained in plain language
- **No dependencies** — Pure HTML, CSS, and vanilla JavaScript — works offline

---

## 🚀 Getting Started

### Open directly in your browser

```bash
git clone https://github.com/YOUR-USERNAME/election-process-assistant.git
cd election-process-assistant
open index.html
```

### Deploy on GitHub Pages (free hosting)

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to `main` branch → `/root`
4. Click **Save**
5. Live at: `https://YOUR-USERNAME.github.io/election-process-assistant`

---

## 📁 Project Structure

```
election-process-assistant/
├── index.html    ← Entire app (HTML + CSS + JS)
└── README.md     ← This file
```

---

## 🛠️ Customization

All content is stored as JavaScript arrays at the top of the `<script>` block in `index.html`:

| Variable | What it controls |
|---|---|
| `timelineData` | Election timeline steps |
| `conceptsData` | Key concepts cards |
| `rolesData` | Roles and responsibilities |
| `quizData` | Quiz questions and answers |
| `glossaryData` | Glossary terms |

Edit these arrays to adapt the content for any country's electoral system.

---

## 🌍 Use Cases

- Civic education in schools and universities
- Voter awareness campaigns by NGOs
- Personal learning and reference
- Government outreach programs

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

> *Democracy works best when citizens understand it.*
